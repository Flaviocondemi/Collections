package UI;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        long startTime;
        long endTime;
        long duration;

        //Collections

        List arrayList = new ArrayList();
        List vector = new Vector();
        List linkedList = new LinkedList();

        Set treeset = new TreeSet();
        Set hashset = new HashSet();

        Queue priorityQueue = new PriorityQueue();


        /* ----- SET -----*/

        // arrayList add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            arrayList.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("ArrayList add:  " + duration);

        //Vector add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            vector.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Vector add:  " + duration);

        //Treeset add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            treeset.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Treeset add:  " + duration);

        //hashset add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            hashset.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Hashset add:  " + duration);

        //priorityQueue add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            priorityQueue.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("PriorityQueue add:  " + duration);

        // LinkedList add
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            linkedList.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("LinkedList add: " + duration);

        System.out.println("");

        /* -----  GET ----- */


        // arrayList get
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            arrayList.add(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("ArrayList add:  " + duration);

        //Vector get
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            vector.get(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Vector add:  " + duration);

        //Treeset get
        startTime = System.nanoTime();
        Iterator iterator = treeset.iterator();
        for (int i = 0; i < 150000; i++) {
           iterator.next();
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Treeset add:  " + duration);

        //hashset get
        startTime = System.nanoTime();
        Iterator iteratorhash = treeset.iterator();
        for (int i = 0; i < 150000; i++) {
            iteratorhash.next();
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Hashset add:  " + duration);

        //priorityQueue get
        startTime = System.nanoTime();
        Iterator iteratorQueue = treeset.iterator();
        for (int i = 0; i < 150000; i++) {
            iteratorQueue.next();
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("PriorityQueue add:  " + duration);

        // LinkedList get
        startTime = System.nanoTime();

        for (int i = 0; i < 150000; i++) {
            linkedList.get(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("LinkedList add: " + duration);

        System.out.println("");


        // ArrayList remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            arrayList.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("ArrayList remove:  " + duration);

        // LinkedList remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            linkedList.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("LinkedList remove: " + duration);

        // Vector remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            vector.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("vector remove: " + duration);

        // Hashset remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            hashset.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Hashset remove: " + duration);

        // Treeset remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            treeset.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("Treeset remove: " + duration);

        // PriorityQueue remove
        startTime = System.nanoTime();

        for (int i = 15000; i >=0; i--) {
            linkedList.remove(i);
        }
        endTime = System.nanoTime();
        duration = endTime - startTime;
        System.out.println("PriorityQueue remove: " + duration);
    }


}
